import React, {useEffect, useState } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom";

function Home(){
    const [user, setUser] = useState({});

    const navigate = useNavigate();

    //token
    const token = localStorage.getItem("token");

    useEffect(() => {
        if(!token){
            navigate('/login');
        }else{
            fetchData();
        }
    },[]);

    const fetchData = async () => {
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
        await axios.post('http://127.0.0.1:8000/api/auth/me')
        .then((response) => {
            setUser(response.data);
        })
    }

    const logoutHandler = async () => {
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`
        await axios.post('http://127.0.0.1:8000/api/auth/logout')
        .then(() => {
            localStorage.removeItem("token");

            navigate('/');
        })
    }
    return(
        <div className="container">
            <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                <a className="navbar-brand" href="#">Home</a>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNavDropdown">
                <ul className="navbar-nav">
                    <li className="nav-item">
                    <a className="nav-link" href="#">Audit Trail</a>
                    </li>
                    <li className="nav-item dropdown">
                    <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                       User Management
                    </a>
                    <ul className="dropdown-menu">
                        <li><a className="dropdown-item" href="#">User</a></li>
                        <li><a className="dropdown-item" href="#">Role</a></li>
                        <li><a className="dropdown-item" href="#">Menu</a></li>
                        <li><a className="dropdown-item" href="#">Permission</a></li>
                    </ul>
                    </li>
                </ul>
                <button onClick={logoutHandler} className="btn btn-outline-danger my-2 my-sm-0">Logout</button>
                </div>
            </div>
            </nav>

            <div className="d-flex align-items-center" style={{height: '80vh'}}>
                <div style={{width: '100%'}}>
                    <div className="row justify-content-center">
                        <div className="col-md-8">
                            <div className="card">
                                <div className="card-header">Welcome</div>
                                <div className="card-body">
                                    <p>{user.name}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Home;